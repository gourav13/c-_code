#include<iostream>
#include<map>
#include<algorithm>
#include<list>
#include<string>

using namespace std;

class Graph{
    int V;
    map<string,list<string> > m;
public:
    Graph(int v){
        V = v;
    }

    void addEdge(string u,string v,bool bidir=true){
        m[u].push_back(v);
        if(bidir){
            m[v].push_back(u);
        }
    }
    void dfsHelper(string city,map<string,bool> &visited){
            cout<<city<<" ";
            visited[city] = true;

            for(auto it=m[city].begin();it!=m[city].end();it++){
                if(!visited[*it]){
                        dfsHelper(*it,visited);
                }
            }
    }

    void dfs(string src){
        map<string,bool> visited;

        for(auto it=m.begin();it!=m.end();it++){
            visited[it->first] = false;
        }

        dfsHelper(src,visited);
        cout<<endl;

          for(auto it=m.begin();it!=m.end();it++){
            if(visited[it->first] == false){
                dfsHelper(it->first,visited);
                cout<<endl;
            }
        }



    }

};

int main(){
    Graph  g(7);
    g.addEdge("A","B");
    g.addEdge("A","C");
    g.addEdge("A","D");
    g.addEdge("B","C");
    g.addEdge("C","E");
    g.addEdge("F","G");

    g.dfs("E");



return 0;
}
