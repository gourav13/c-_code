#include<iostream>
#include<unordered_map>
using namespace std;




int main(){

    pair<string,int> p;
    p.first = "Mango";
    p.second = 100;
    cout<<p.first <<endl;


    unordered_map<string, int> m;

    ///Insert

    m.insert(p);
    m["apple"]=200;

    ///Search
    string fruit;
    cin>>fruit;
    if(m.count(fruit)>0){
        cout<<"price of fruit is "<<m[fruit];
    }
    else{
        cout<<"not found "<<endl;
    }




return 0;
}
