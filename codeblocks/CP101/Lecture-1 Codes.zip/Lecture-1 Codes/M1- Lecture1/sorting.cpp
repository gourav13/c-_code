#include<iostream>
#include<unordered_map>
#include<algorithm>
using namespace std;

bool myCompare(int a,int b){
    return a>b;
}


int main(){

    int a[] = {2,3,7,8,9,5};
    sort(a,a+6,myCompare);
    for(int i=0;i<6;i++){
        cout<<a[i]<<endl;
    }


return 0;
}
