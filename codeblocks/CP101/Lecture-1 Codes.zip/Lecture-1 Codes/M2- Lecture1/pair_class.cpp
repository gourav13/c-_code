#include<bits/stdc++.h>
using namespace std;

/*
template<typename U,typename V>
class Pair {
public:
    T first;
    U second;
};
*/



int main(){

    pair<string,int> p;
    p.first = "Apple";
    p.second = 80;

    unordered_map<string,int> m;
    m.insert(p);
    m["mango"] = 100;

    string fruit;
    cin>>fruit;

    if(m.count(fruit)>0){
    cout<<"Price of fruit is "<<m[fruit]<<endl;;
    }
    else{
        cout<<"Fruit doesnt exist "<<endl;
    }

    ///Priority queue
    priority_queue<int,vector<int>, greater<int> > pq;

    int a[] = {4,3,2,5,1};

    for(int i=0;i<5;i++){
        pq.push(a[i]);
    }

    while(!pq.empty()){

        cout<< pq.top()<< " ";
        pq.pop();
    }


return 0;
}


