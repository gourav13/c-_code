#include<bits/stdc++.h>
using namespace std;

bool compare(int a,int b){
    return a>b;
}

int main(){

    int a[] = {1,2,5,4,3,6};
    sort(a,a+6,compare);

    for(int i=0;i<6;i++){
        cout<<a[i]<<" ";
    }

return 0;
}



