#include<iostream>
#include<map>
#include<string>
#include<list>
using namespace std;

class Graph{
    int V;
    map<string,list<string> > m;
public:
    Graph(int v){
        V=v;
    }

    void addEdge(string u,string v,bool bidir=true){
            m[u].push_back(v);
            if(bidir){
                m[v].push_back(u);
            }
    }
    void dfsHelper(string city,map<string,bool> &visited){

    cout<<city<<" ";
    visited[city] = true;

    for(auto it=m[city].begin();it!=m[city].end();it++){
        if(visited[*it]==false){
            dfsHelper(*it,visited);
            }
        }
    return;
    }

    void dfs(string src){
        map<string, bool> visited;

        for(auto it=m.begin();it!=m.end();it++){
            visited[it->first] = false;
        }

        dfsHelper(src,visited);
        cout<<endl;

         for(auto it=m.begin();it!=m.end();it++){
            //visited[it->first] = false;
            if(!visited[it->first]){
                dfsHelper(it->first,visited);
                cout<<endl;
            }
        }
    }
};


int main(){

    Graph g(7);
    g.addEdge("A","B");
    g.addEdge("A","D");
    g.addEdge("A","C");
    g.addEdge("C","D");
    g.addEdge("E","D");


    g.addEdge("F","G");

    g.dfs("E");

    return 0;
}
